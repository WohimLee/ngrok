1. ngrok.d copy to /etc/init.d/ngrok.d 
2. sudo systemctl start ngrok.d
3. sudo systemctl daemon-reload